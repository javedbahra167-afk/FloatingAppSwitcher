package com.example.floatswitcher

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

class GroceryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val et = EditText(context).apply { hint = "Quick grocery / note..." }
            val btnSave = Button(context).apply { text = "Save (temp)" }
            addView(et)
            addView(btnSave)
            btnSave.setOnClickListener {
                // Very simple — you can persist to DB or prefs
            }
        }
        setContentView(layout)
    }
}
