package com.example.floatswitcher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings

object Utils {
    private const val PREFS = "float_prefs"
    private const val KEY_TARGET = "target_pkg"
    const val BUILTIN_TARGET = "__BUILTIN__"

    fun saveTargetPackage(ctx: Context, pkg: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_TARGET, pkg).apply()
    }

    fun getTargetPackage(ctx: Context): String? {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_TARGET, null)
    }

    fun launchTarget(ctx: Context) {
        val target = getTargetPackage(ctx)
        if (target == null) {
            // nothing selected, open settings
            ctx.startActivity(Intent(ctx, SettingsActivity::class.java).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            return
        }

        if (target == BUILTIN_TARGET) {
            ctx.startActivity(Intent(ctx, GroceryActivity::class.java).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            return
        }

        // Try to open external app by package
        val pm = ctx.packageManager
        val launch = pm.getLaunchIntentForPackage(target)
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(launch)
        } else {
            // fallback: open Play Store
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$target"))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
        }
    }
}
