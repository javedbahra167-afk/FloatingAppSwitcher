package com.example.floatswitcher

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    private lateinit var pm: PackageManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        pm = packageManager
        val listView = findViewById<ListView>(R.id.lv_apps)
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .map { Pair(it.loadLabel(pm).toString(), it.packageName) }
            .sortedBy { it.first }

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, apps.map { it.first })
        listView.adapter = adapter

        listView.setOnItemClickListener { _, _, position, _ ->
            val selection = apps[position]
            Utils.saveTargetPackage(this, selection.second)
            finish()
        }

        val openBuiltIn = findViewById<Button>(R.id.btn_open_builtin)
        openBuiltIn.setOnClickListener {
            // Choose built-in Grocery/Notes activity as target
            Utils.saveTargetPackage(this, Utils.BUILTIN_TARGET)
            startActivity(Intent(this, GroceryActivity::class.java))
        }
    }
}
