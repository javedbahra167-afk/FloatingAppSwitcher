package com.example.floatswitcher

import android.app.Service
import android.content.Intent
import android.os.IBinder

class FloatingService : Service() {

    private var floatingView: FloatingView? = null

    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createNotificationChannel(this)
        val notification = NotificationHelper.buildForegroundNotification(this)
        startForeground(NotificationHelper.NOTIF_ID, notification)

        floatingView = FloatingView(this) { // onClick
            // Launch target
            Utils.launchTarget(this)
        }

        floatingView?.attachToWindow()
    }

    override fun onDestroy() {
        floatingView?.detachFromWindow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
